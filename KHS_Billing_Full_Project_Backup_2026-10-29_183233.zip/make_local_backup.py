import os, sys, zipfile
from datetime import datetime

now_str = datetime.now().strftime("%Y-%m-%d_%H%M%S")
zip_name = f"KHS_Billing_Full_Project_Backup_{now_str}.zip"

ignore_dirs = {'.gradle', 'build', 'pyruntime', 'mingit', '.idea', '__pycache__', '.pytest_cache'}

with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk('.'):
        dirs[:] = [d for d in dirs if d not in ignore_dirs and not d.startswith('.git')]
        for file in files:
            if file.endswith('.zip') or file.endswith('.iso'):
                continue
            file_path = os.path.join(root, file)
            arcname = os.path.relpath(file_path, '.')
            zipf.write(file_path, arcname)

size_mb = os.path.getsize(zip_name) / (1024 * 1024)
print(f"Zip created: {zip_name} ({size_mb:.2f} MB)")

# Copy to user Desktop or Downloads for safety
user_profile = os.environ.get('USERPROFILE', '')
desktop_backup = os.path.join(user_profile, 'Desktop', zip_name)
downloads_backup = os.path.join(user_profile, 'Downloads', zip_name)

import shutil
shutil.copy2(zip_name, desktop_backup)
print(f"Saved secure backup to Desktop: {desktop_backup}")
