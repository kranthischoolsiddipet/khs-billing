import os, sys, shutil, zipfile
from datetime import datetime
from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

# 1. Create timestamped zip of KHS Billing folder
now_str = datetime.now().strftime("%Y-%m-%d_%H%M%S")
zip_name = f"KHS_Billing_Full_Project_Backup_{now_str}.zip"

print(f"Creating project zip backup: {zip_name}...")
ignore_dirs = {'.gradle', 'build', 'pyruntime', 'mingit', '.idea', '__pycache__', '.pytest_cache'}

with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk('.'):
        dirs[:] = [d for d in dirs if d not in ignore_dirs and not d.startswith('.git')]
        for file in files:
            if file.endswith('.zip') or file.endswith('.iso'):
                continue
            file_path = os.path.join(root, file)
            arcname = os.path.relpath(file_path, '.')
            zipf.write(file_path, arcname)

size_mb = os.path.getsize(zip_name) / (1024 * 1024)
print(f"Zip created! Size: {size_mb:.2f} MB")

# 2. Upload zip and current APK to Google Drive folder
creds = service_account.Credentials.from_service_account_file(
    'service_account.json',
    scopes=['https://www.googleapis.com/auth/drive']
)
service = build('drive', 'v3', credentials=creds)
folder_id = '1nUH0mD0-L8-2K5uydOMnjlr8_FUz7Shc'

print("Uploading project zip to Google Drive...")
media = MediaFileUpload(zip_name, mimetype='application/zip', resumable=True)
uploaded = service.files().create(
    body={'name': zip_name, 'parents': [folder_id]},
    media_body=media,
    fields='id, name, webViewLink'
).execute()
print(f"Successfully uploaded project backup to Google Drive! File ID: {uploaded.get('id')}")

# Also upload the APK file
apk_name = 'khs-billing-v1.3.0.apk'
if os.path.exists(apk_name):
    print(f"Uploading APK ({apk_name}) to Google Drive...")
    apk_media = MediaFileUpload(apk_name, mimetype='application/vnd.android.package-archive', resumable=True)
    apk_file = service.files().create(
        body={'name': f"khs_billing_app_{now_str}.apk", 'parents': [folder_id]},
        media_body=apk_media,
        fields='id, name, webViewLink'
    ).execute()
    print(f"Successfully uploaded APK to Google Drive! File ID: {apk_file.get('id')}")

# Make APK downloadable publicly if needed
service.permissions().create(
    fileId=apk_file['id'],
    body={'role': 'reader', 'type': 'anyone'}
).execute()
public_apk = service.files().get(fileId=apk_file['id'], fields='webContentLink, webViewLink').execute()
print("Direct Google Drive Public APK link:", public_apk.get('webContentLink') or public_apk.get('webViewLink'))

# Clean local zip
os.remove(zip_name)
print("Done!")
